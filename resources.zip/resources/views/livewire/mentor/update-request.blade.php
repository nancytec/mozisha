<div>
    <div class="modal-dialog modal-dialog-centered" role="document" >
        <div class="modal-content" style="background-color: #420175 !important; color: white;">
            <div class="modal-header">
                <h5 class="modal-title" style="color: white;">Incomplete profile</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: white;">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-header">
                <p style="text-align: center;">Sorry, you have to complete your profile in order to post any apprenticeship program!.</p>
            </div>

            <div class="modal-body">
            </div>
        </div>
    </div>
</div>
