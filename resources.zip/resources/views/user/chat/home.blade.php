
@extends('layouts.chat.app')

@section('content')



        {{--<livewire:dashboard />--}}
        @livewire('chat-home')



@endsection

