<html>
<head>
    @livewireStyles
</head>
<body>

<livewire:test />


@livewireScripts
</body>
</html>




